#include "stm32f10x.h"
#include "interface.h"
#include "LCD1602.h"
#include "IRCtrol.h"
#include "motor.h"
#include "uart.h"

//Defining global variables
unsigned int speed_count=0;//Duty cycle counter, 50 times a cycle
char front_left_speed_duty=SPEED_DUTY;
char front_right_speed_duty=SPEED_DUTY;
char behind_left_speed_duty=SPEED_DUTY;
char behind_right_speed_duty=SPEED_DUTY;

unsigned char tick_5ms = 0;//5ms counter, as the basic period of the main function
unsigned char tick_1ms = 0;//1ms counter, as the basic counter of the motor
unsigned char tick_200ms = 0;//refresh

char ctrl_comm = COMM_STOP;//Control instruction
char ctrl_comm_last = COMM_STOP;//Previous instruction
unsigned char continue_time=0;
unsigned char bt_rec_flag=0;//Bluetooth control flag bit
int i=0;

//Tracking, by judging the state of the three photoelectric tube to control the car movement
	//We got it on all three routes

int main(void)
{
	delay_init();
	GPIOCLKInit();
	UserLEDInit();
	LCD1602Init();
	//IRCtrolInit();
	TIM2_Init();
	MotorInit();
	ServoInit();
	
	RedRayInit();
	//USART3Conf(9600);

 while(1)
 {	 
	 		if(tick_5ms >= 5)
		{
			tick_5ms = 0;
			tick_200ms++;
			if(tick_200ms >= 40)
			{
				tick_200ms = 0;
				LEDToggle(LED_PIN);
			}
		  if(SEARCH_M_IO == BLACK_AREA && SEARCH_L_IO == BLACK_AREA && SEARCH_R_IO == BLACK_AREA)
			{
				i++;
			}
			if(i==1)
			{
				CarGo();
				Delayms(100);
			}
			if(i==2||i==13||i==21||i==30)
			{
				CarLeft();
				Delayms(100);
				CarGo();
				Delayms(50);
			}
			if(i==3||i==9||i==12||i==20||i==29)
			{
				CarRight();
				Delayms(100);
				CarGo();
				Delayms(50);
			}
			if(i==4||i==5||i==6||i==7||i==14||i==15||i==22||i==23||i==31||i==32||i==33)
			{
				CarGo();
				Delayms(100);
			}
			if(i==8||i==9||i==24||i==25)
			{
				CarRight();
				Delayms(50);
				CarBack();
				Delayms(50);
			}
			if(i==10||i==11||i==18||i==19||i==26||i==27||i==28)
			{
				CarBack();
				Delayms(100);
			}
			if(i==16||i==17)
			{
				CarLeft();
				Delayms(50);
				CarBack();
				Delayms(50);
			}
			if(i==34)
			{
				CarLeft();
				Delayms(50);
			}
			}
		}		
 }


