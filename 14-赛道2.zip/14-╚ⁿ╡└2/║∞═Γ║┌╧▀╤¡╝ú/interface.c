#include "interface.h"

void delay_init(void)
{
   SysTick->CTRL&=0xfffffffb;//Control register, select the external clock that is 1/8th of the system clock��HCLK/8��72M/8=9M��
}

//1us delay function
void Delay_us(u32 Nus)   
{   
SysTick->LOAD=Nus*9;          //Time to load    72M      
SysTick->CTRL|=0x01;             //Start from bottom   
while(!(SysTick->CTRL&(1<<16))); //Waiting time arrival    
SysTick->CTRL=0X00000000;        //Off counter  
SysTick->VAL=0X00000000;         //clear counter           
} 

void Delayms(u32 Nms)
{
	while(Nms--)
	{
		Delay_us(1000);
	}
}

//turn on the clock of all GPIO
void GPIOCLKInit(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA , ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB , ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC , ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD , ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE , ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOF , ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOG , ENABLE);
}

void UserLEDInit(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin = LED_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//Configure the GPIO port speed
	GPIO_Init(LED_GPIO , &GPIO_InitStructure);
	
	LED_SET;	
}

void ServoInit(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin = Servo_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//Configure the GPIO port speed
	GPIO_Init(Servo_GPIO , &GPIO_InitStructure);
	
	Servo_SET;//Default is high level
}


//Infrared photoelectric pair tube initialization
void RedRayInit(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin = SEARCH_M_PIN;//Enable GPIO pins
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;//Configure GPIO mode and enter pull-up
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//Configure the GPIO port speed
	GPIO_Init(SEARCH_M_GPIO , &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin = SEARCH_R_PIN;//Enable GPIO pins
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;//Configure GPIO mode and enter pull-up
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//Configure the GPIO port speed
	GPIO_Init(SEARCH_R_GPIO , &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin = SEARCH_L_PIN;//Enable GPIO pins
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;//Configure GPIO mode and enter pull-up
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//Configure the GPIO port speed
	GPIO_Init(SEARCH_L_GPIO , &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin = VOID_R_PIN;//Enable GPIO pins
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;//Configure GPIO mode and enter pull-up
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//Configure the GPIO port speed
	GPIO_Init(VOID_R_GPIO , &GPIO_InitStructure); 
	
	GPIO_InitStructure.GPIO_Pin = VOID_L_PIN;//Enable GPIO pins
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;//Configure GPIO mode and enter pull-up
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//Configure the GPIO port speed
	GPIO_Init(VOID_L_GPIO , &GPIO_InitStructure); 
}


/**-------------------------------------------------------
  *  NVIC_TIM5Configuration
  *  Configure the TIM5 interrupt vector parameter function
***------------------------------------------------------*/
static void NVIC_TIM2Configuration(void)
{ 
    NVIC_InitTypeDef NVIC_InitStructure;

    /* Set the Vector Table base address at 0x08000000 */
    //NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0000);

    /* Enable the TIM5 gloabal Interrupt */
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;

    NVIC_Init(&NVIC_InitStructure);
}


void TIM2_Init(void)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;

    /* TIM2 clock enable */
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

    /* Time base configuration */
    TIM_TimeBaseStructure.TIM_Period = (100 - 1);//10kHz
    TIM_TimeBaseStructure.TIM_Prescaler = (72 - 1);//1MHz
    TIM_TimeBaseStructure.TIM_ClockDivision = 0;
    //Counting up
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    //Initialize timer 5
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

    /* Clear TIM5 update pending flag */
    TIM_ClearITPendingBit(TIM2, TIM_IT_Update);

    /* TIM IT enable */ //Open overflow interrupt
    TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);

    /* TIM5 enable counter */
    TIM_Cmd(TIM2, ENABLE);  //The counter is enabled to work

    /* Interrupt Parameter Configuration */
    NVIC_TIM2Configuration();
}

void LEDToggle(uint16_t Led)
{
	LED_GPIO->ODR ^= Led;
	// LEDnOBB = !LEDnOBB;
}


