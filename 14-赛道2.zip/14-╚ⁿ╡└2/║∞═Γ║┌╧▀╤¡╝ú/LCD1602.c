#include "LCD1602.h"
#include "interface.h"
#include "stm32f10x.h"

//Defining global variables
unsigned char const table1[]="Hantech MCU";
unsigned char const table2[]="Command:";

/*******************************************************************************
* LcdBusy
*******************************************************************************/
//bit LcdBusy()
// {                          
//    bit result;
//    LCDRS_RESET;
//    LCDWR_SET;
//    LCDEN_SET;
//    Delay_us(1);
//    result = (bit)(P0&0x80);
//    LCDEN_RESET;
//    return(result); 
//}
 
/*******************************************************************************
* write_com
* LCD1602 write order
*******************************************************************************/
void LcdWriteCom(unsigned char com)
{
	//while(LcdBusy());
	Delay_us(20);
	LCDWRITE_DATA(com);
	LCDRS_RESET;
	LCDWR_RESET;
	LCDEN_RESET;
	Delay_us(10);
	LCDEN_SET;
	Delay_us(10);
	LCDEN_RESET;
	Delay_us(10);
}

/*******************************************************************************
* write_com
* LCD1602 write data
*******************************************************************************/
void LcdWriteDate(unsigned char date)
{
	//while(LcdBusy());
	Delay_us(20);
	LCDWRITE_DATA(date);
	LCDRS_SET;
	LCDWR_RESET;
	LCDEN_RESET;
	Delay_us(10);
	LCDEN_SET;
	Delay_us(10);
	LCDEN_RESET; 
	Delay_us(10);	
}

void LCD1602PortInit()
{
  GPIO_InitTypeDef  GPIO_InitStructure;
	
	GPIO_InitStructure.GPIO_Pin = LCDRS_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//Configure the GPIO port speed
	GPIO_Init(LCDRS_GPIO , &GPIO_InitStructure);	
	
	GPIO_InitStructure.GPIO_Pin = LCDWR_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//Configure the GPIO port speed
	GPIO_Init(LCDWR_GPIO , &GPIO_InitStructure);	

	GPIO_InitStructure.GPIO_Pin = LCDEN_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//Configure the GPIO port speed
	GPIO_Init(LCDEN_GPIO , &GPIO_InitStructure);	

	GPIO_InitStructure.GPIO_Pin = LCD_PORT;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;//Configure the GPIO port speed
	GPIO_Init(LCD_GPIO , &GPIO_InitStructure);		
}

/*******************************************************************************
* LCD1602Init
* LCD1602 initialization
*******************************************************************************/
void LCD1602Init()
{
	char index=0;
	LCD1602PortInit();
	Delayms(100);
	LcdWriteCom(0x38);  //Set up 16*2 display, 8 bit data interface
	LcdWriteCom(0x0c); //Turn on display, display cursor and blink
	LcdWriteCom(0x06);//Write a pointer automatically incremented by one
	LcdWriteCom(0x01);//Clear the screen 
	Delayms(100);
	
	LcdWriteCom(0x80);//Set the first line, the data address pointer
	for(index=0;index<11;index++)
	{
		LcdWriteDate(table1[index]);  //write data            
	}
	
	LcdWriteCom(0xc0);//Set the second line, the data address pointer
	for(index=0;index<8;index++)
	{
		LcdWriteDate(table2[index]);  //write data            
	}
}

/*******************************************************************************
* LCD1602WriteCommand
* Display instructions to the screen U D L R S 
*******************************************************************************/
void LCD1602WriteCommand(char comm)
{
	LcdWriteCom(0xc0 + 9);
	LcdWriteDate(comm);  //write data  
}

