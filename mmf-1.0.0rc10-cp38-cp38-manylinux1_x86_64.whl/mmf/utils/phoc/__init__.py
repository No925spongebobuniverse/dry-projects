# Copyright (c) Facebook, Inc. and its affiliates.

from .build_phoc import build_phoc  # NoQA
