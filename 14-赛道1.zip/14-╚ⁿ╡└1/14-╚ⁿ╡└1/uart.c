#include "uart.h"
#include "interface.h"

//UART function
//UART1 TxD GPIOA9   RxD GPIOA10
void USART1Conf(u32 baudRate)
{
	USART_InitTypeDef USART_InitSturct;//Define the initialization structure for serial port 1

	GPIO_InitTypeDef GPIO_InitStruct;//Defines the structure of the pins corresponding to the serial port

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA , ENABLE);//Turn on the serial port pin clock
	//USART1_Tx_Pin Configure 
	GPIO_InitStruct.GPIO_Pin = GPIO_Pin_9;//The output pin
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_2MHz;//Set the maximum speed of 50MHz
	GPIO_InitStruct.GPIO_Mode = GPIO_Mode_AF_PP;//Push-pull multiplexing output
	GPIO_Init(GPIOA , &GPIO_InitStruct);//Load the initialized structure into the register

//USART1_Rx_Pin Configure
  GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IN_FLOATING;//GPIO mode floating input
  GPIO_InitStruct.GPIO_Pin = GPIO_Pin_10;//The output pin
  GPIO_Init(GPIOA, &GPIO_InitStruct);//Load the initialized structure into the register

//USART1 Configure	
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1 , ENABLE);//The clock can make
	USART_InitSturct.USART_BaudRate = baudRate;//19200 baud rates,
	USART_InitSturct.USART_WordLength = USART_WordLength_8b;//Data width 8 bits
	USART_InitSturct.USART_StopBits = USART_StopBits_1;//One stop bit
	USART_InitSturct.USART_Parity = USART_Parity_No;//None Parity check
	USART_InitSturct.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_InitSturct.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;//Enable sending and receiving
	USART_Init(USART1 , &USART_InitSturct);//Load the initialized structure into the register
	//USART1_INT Configure
	USART_ITConfig(USART1 , USART_IT_RXNE , ENABLE);//Enable receiving interrupt
//	USART_ITConfig(USART1 , USART_IT_TXE , ENABLE);
	USART_Cmd(USART1 , ENABLE);//Open the serial port
	USART_ClearFlag(USART1 , USART_FLAG_TC);//Resolve the first data send failure
}

void PutChar(u8 Data)
{
	USART_SendData(USART1 , Data);
	while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);//Wait for delivery
}
void PutStr(char *str)//Send a string
{
	while(*str != '\0')
	{
		USART_SendData(USART1 , *str++);
		while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);//Wait for delivery
	}
}

void PutNChar(u8 *buf , u16 size)
{
  u8 i;
	while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET); //Prevents first byte loss
	for(i=0;i<size;i++)
	{
		 USART_SendData(USART1 , buf[i]);
		 while (USART_GetFlagStatus(USART1, USART_FLAG_TC) == RESET);//Wait for delivery
	}
}



