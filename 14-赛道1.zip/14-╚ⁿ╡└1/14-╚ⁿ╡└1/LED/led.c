#include "led.h"
#include "stm32f10x.h"

void Flame_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;//define a structure variable of type GPIO_InitTypeDef

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC,ENABLE);//turn on the clock of GPIOA
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//turn on the clock of GPIOB
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE,ENABLE);//turn on the clock of GPIOE
	
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;//pull-up input
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_1;//select the I/O pin to use, here select the PC1 pin
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;//set the output speed of the pin to 50MHz
	GPIO_Init(GPIOC,&GPIO_InitStructure);//call the initialization library function to initialize the GPIOA port
  
	
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_Out_PP;//set the pin output mode to push-pull output
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_0;//select the I/O pin to use, here select the PE6 pin
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;//set the output speed of the pin to 50MHz
	GPIO_Init(GPIOE,&GPIO_InitStructure);//call the initialization library function to initialize the GPIOE port
	
	
	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;//pull-up input
	GPIO_InitStructure.GPIO_Pin=GPIO_Pin_1;//select the I/O pin to use, here select the PA1 pin
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;//set the output speed of the pin to 50MHz
	GPIO_Init(GPIOA,&GPIO_InitStructure);//call the initialization library function to initialize the GPIOB port
}





