//���ӷ�ʽ ����ο�interface.h�ļ�
//����Դ����Դ����--������24Сʱ��ɾ��
#include "stm32f10x.h"
#include "interface.h"
#include "LCD1602.h"
#include "IRCtrol.h"
#include "motor.h"
#include "UltrasonicCtrol.h"
#include "led.h"
#include "sys.h"
#include "adc.h"

#define T GPIO_ReadInputDataBit(GPIOC, GPIO_Pin_1)
#define L GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1)

//Global variables defined
unsigned int speed_count=0;//Duty cycle counter 50 times a cycle
char front_left_speed_duty=SPEED_DUTY;
char front_right_speed_duty=SPEED_DUTY;
char behind_left_speed_duty=SPEED_DUTY;
char behind_right_speed_duty=SPEED_DUTY;

unsigned char tick_5ms = 0;//5ms counter, as the basic period of the main function
unsigned char tick_1ms = 0;//1ms counter, as the basic counter of the motor
unsigned char tick_200ms = 0;//refresh display

char ctrl_comm = COMM_STOP;//control instruction
char ctrl_comm_last = COMM_STOP;//Previous instruction
unsigned char continue_time=0;

unsigned char duoji_count=0;
unsigned char zhuanjiao = 11;

//The voltage value converted by ADC1 is transmitted to SRAM via DMA
extern  __IO uint16_t  ADC_Converted_Value;//0-4095
//Defines a local variable to hold the voltage value calculated after the conversion
float  ADC_ConvertedValueLocal; //0-3.3   V

// The timer period is 0.1ms
// The PWM cycle of the steering gear is 20ms, 0-180 �� corresponds to 0.5-2.5ms pulse width respectively
// Variable zhuanjiao can be adjusted from 5-25 to 0-180 ��, or 90�� when zhuanjiao = 15
// In order to make the steering gear more accurate, it is recommended not to use 0�� or 180�� to the right or left, but to move closer to the center
// Select "zhuanjiao=7" for right turns and "zhuanjiao=23" for left turns
void DuojiMid()
{
	zhuanjiao = 15;
	Delayms(500);
}

void DuojiRight()
{
	zhuanjiao = 25;
	Delayms(500);
}

void DuojiLeft()
{
	zhuanjiao = 6;
	Delayms(500);
}
void VoidRun(void);

int main(void)
{
	delay_init();
	GPIOCLKInit();
	UserLEDInit();
	//LCD1602Init();
	//IRCtrolInit();
	TIM2_Init();
	MotorInit();
	UltraSoundInit();
	RedRayInit();
	ServoInit();
	DuojiMid();
	Delayms(500);
	ADC1_Init();
	Flame_Init();
	
	ADC_SoftwareStartConvCmd(ADC1, ENABLE);	        //ADC Begin Conversion
	
	
 while(1)
 {	 

	 ADC_ConvertedValueLocal =(float) ADC_Converted_Value /4096*3.3;

	 switch(ADC_Converted_Value/100)
				{
					case 11:  
 						DuojiLeft();
	 					break;
					case 13:  
						DuojiMid();
						break;
					case 16:  
						DuojiRight();
						break;
					default : break;
				}
	 
	 if(tick_5ms >= 5)
		{
			tick_5ms = 0;
			tick_200ms++;
			if(tick_200ms >= 40)
			{
				tick_200ms = 0;
				LEDToggle(LED_PIN);
			}
			continue_time--;//200ms Stop without receiving instructions
			if(continue_time == 0)
			{
				continue_time = 1;
				CarStop();
			}
			//do something
			VoidRun();
		}
		
				
	if(T==0&&L==1)
   {
		 CarStop();
		 GPIO_ResetBits(GPIOE,GPIO_Pin_0);
	 }	
	 if(T==1&&L==1)
   {
		 GPIO_SetBits(GPIOE,GPIO_Pin_0);
		 CarGo();
	 }	
   if(L==0&&T==1)
   {
		CarStop();		 
	 }		
	 if(L==1&&T==1)
   {
		CarGo();
	 }

		}		
 }
